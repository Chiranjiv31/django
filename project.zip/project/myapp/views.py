from django.shortcuts import render, get_object_or_404, redirect
from . models import Office

# Create your views here.
def office_list(request):
    office = Office.objects.all()
    return render (request, 'myapp/office_list.html', {'office': office})

def office_create(request):
    if request.method == 'POST':
        name=request.POST.get('name')
        location=request.POST.get('location')
        employees_count = request.POST.get('employees_count')
        Office.objects.create(name=name, location=location, employees_count=employees_count)
        return redirect('office_list') #- it redirect the page after create
    return render(request, 'myapp/office_create.html')

def office_detail(request, pk): #- pk= primary key
    office = get_object_or_404(Office, pk=pk)
    return render (request, 'myapp/office_detail.html', {'office':Office})

def office_delete(request,pk):
    office= get_object_or_404(Office,pk=pk)
    if request.method=='POST':
        Office.delete()
        return redirect('office_list')
    return render(request, 'myapp/office_delete.html', {'Office':Office})

    


